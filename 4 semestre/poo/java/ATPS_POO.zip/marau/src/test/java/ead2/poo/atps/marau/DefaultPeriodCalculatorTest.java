package ead2.poo.atps.marau;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;

import org.junit.Test;

public class DefaultPeriodCalculatorTest {
	
	@Test
	public void firstPeriodSample() throws ParseException {
		assertEquals(3, DefaultPeriodCalculator.countDays("12/07/2012 13:42", "15/07/2012 11:50"));
	}

	@Test
	public void secondPeriodSample() throws ParseException {
		assertEquals(4, DefaultPeriodCalculator.countDays("12/07/2012 17:00", "15/07/2012 16:50"));
	}
}
package ead2.poo.atps.marau;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.text.ParseException;

import org.junit.Before;
import org.junit.Test;

import ead2.poo.atps.marau.rooms.StandardRoom;

public class ReceiptPrinterTest {
	
	@Before
	public void setUp() throws FileNotFoundException {
		ReceiptPrinter.setPrintStream(new NullPrintStream());
	}
	
	@Test
	public void printingTest() throws ParseException {
		Booking booking = new Booking("Jeremias", "12/07/2012 13:42", "15/07/2012 11:50", 0);
		
		new StandardRoom(booking);
			
		ReceiptPrinter.print(booking, 10);
	}

	private static class NullPrintStream extends PrintStream {

		public NullPrintStream() {
			super(new OutputStream() {
				@Override
				public void write(int value) throws IOException {
					// do nothing
				}				
			});
		}
	}
}


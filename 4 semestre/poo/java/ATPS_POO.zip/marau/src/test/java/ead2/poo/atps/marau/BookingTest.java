package ead2.poo.atps.marau;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;

import org.junit.Before;
import org.junit.Test;

import ead2.poo.atps.marau.rooms.CottageRoom;
import ead2.poo.atps.marau.rooms.FancyRoom;
import ead2.poo.atps.marau.rooms.Room;
import ead2.poo.atps.marau.rooms.StandardRoom;

public class BookingTest {
	
	@Before
	public void setUp() {
		Booking.STANDARD_DAILY_RATE = 100.0;
	}
	
	@Test
	public void standardDailyRate() throws ParseException {
		Booking booking = new Booking("Gustavo", "13/09/2014 20:15", 0);
		Room room = new StandardRoom(booking);
		
		room.checkout("14/09/2014 09:30");
		
		assertEquals(100.0, booking.getTotalRate(), 0);
	}

	@Test
	public void standardDailyRateWithOneGuest() throws ParseException {
		Booking booking = new Booking("Gustavo", "13/09/2014 20:15", 1);
		Room room = new StandardRoom(booking);
		
		room.checkout("14/09/2014 09:30");
		
		assertEquals(100.0, booking.getTotalRate(), 0);
	}


	@Test
	public void fancyDailyRate() throws ParseException {
		Booking booking = new Booking("Gustavo", "13/09/2014 20:15", 0);
		Room room = new FancyRoom(booking);
		
		room.checkout("14/09/2014 09:30");
		
		assertEquals(118.0, booking.getTotalRate(), 0);
	}

	@Test
	public void fancyDailyRateWithOneGuest() throws ParseException {
		Booking booking = new Booking("Gustavo", "13/09/2014 20:15", 1);
		Room room = new FancyRoom(booking);
		
		room.checkout("14/09/2014 09:30");
		
		assertEquals(118.0, booking.getTotalRate(), 0);
	}

	@Test
	public void cottageDailyRate() throws ParseException {
		Booking booking = new Booking("Gustavo", "13/09/2014 20:15", 0);
		Room room = new CottageRoom(booking);
		
		room.checkout("14/09/2014 09:30");
		
		assertEquals(120.0, booking.getTotalRate(), 0);
	}

	@Test
	public void cottageDailyRateWithOneGuest() throws ParseException {
		Booking booking = new Booking("Gustavo", "13/09/2014 20:15", 1);
		Room room = new CottageRoom(booking);
		
		room.checkout("14/09/2014 09:30");
		
		assertEquals(130.0, booking.getTotalRate(), 0);
	}

}
package ead2.poo.atps.marau.rooms;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;

import org.junit.Before;
import org.junit.Test;

import ead2.poo.atps.marau.Booking;
import ead2.poo.atps.marau.rooms.CottageRoom;
import ead2.poo.atps.marau.rooms.FancyRoom;
import ead2.poo.atps.marau.rooms.Room;
import ead2.poo.atps.marau.rooms.StandardRoom;

public class RoomTest {

	private Booking booking;

	@Before
	public void setUp() throws ParseException {
		booking = new Booking("Fulano", "01/01/2014 12:30", 0);
	}

	@Test
	public void emptyStandardRoom() {
		assertEquals("Padrão       _Vazio_", StandardRoom.EMPTY.toString());
	}

	@Test
	public void occupiedStandardRoom() {
		Room room = new StandardRoom(booking);
		assertEquals("Padrão       Ocupado", room.toString());
	}

	@Test
	public void emptyFancyRoom() {
		assertEquals("Com banheira _Vazio_", FancyRoom.EMPTY.toString());
	}

	@Test
	public void occupiedFancyRoom() {
		Room room = new FancyRoom(booking);
		assertEquals("Com banheira Ocupado", room.toString());
	}

	@Test
	public void emptyCottageRoom() {
		assertEquals("Chalé        _Vazio_", CottageRoom.EMPTY.toString());
	}

	@Test
	public void occupiedCottageRoom() {
		Room room = new CottageRoom(booking);
		assertEquals("Chalé        Ocupado", room.toString());
	}

}
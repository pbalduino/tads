package ead2.poo.atps.marau.rooms;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class RoomListTest {
	
	@Test
	public void onlyStandardRooms() {
		RoomList rooms = new RoomList();
		
		rooms.setSize(10);
		
		for(int i = 0; i < 10; i++) {
			assertTrue(rooms.isEmpty(i));
		}
	}
}

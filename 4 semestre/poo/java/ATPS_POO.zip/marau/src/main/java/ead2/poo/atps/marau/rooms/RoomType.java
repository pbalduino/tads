package ead2.poo.atps.marau.rooms;

public enum RoomType {
	STANDARD {
		@Override
		public String toString() {
			return "Padrão      ";
		}
	},
	
	COTTAGE {
		@Override
		public String toString() {
			return "Chalé       ";
		}
	}, 
	
	BATH {
		@Override
		public String toString() {
			return "Com banheira";
		}		
	}
}
package ead2.poo.atps.marau.rooms;

import ead2.poo.atps.marau.Booking;

public class FancyRoom extends Room {

	public static final Room EMPTY = new FancyRoom(null);

	public FancyRoom(Booking booking) {
		super(booking);
	}

	@Override
	public RoomType getRoomType() {
		return RoomType.BATH;
	}

	@Override
	public double luxuryRate() {
		return 1.18;
	}
	
	@Override
	public Room getEmpty() {
		return EMPTY;
	}
}
/**
 * 
 * Classe responsável por armazenar as informações de hospedagem 
 * 
 */
package ead2.poo.atps.marau;

import java.text.ParseException;

import ead2.poo.atps.marau.rooms.Room;

public class Booking {
	private final String renterName;
	private final String checkin;
	private String checkout;
	private final int guests;
	private int dailyCount;
	private Room room;

	public static double STANDARD_DAILY_RATE;
	
	public Booking(final String renterName, final String checkin, final int guests) throws ParseException {
		this(renterName, checkin, null, guests);
	}

	public Booking(final String renterName, final String checkin, final String checkout, final int guests) throws ParseException {
		this.renterName = renterName;
		this.checkin = checkin;
		this.checkout = checkout;
		this.guests = guests;
		if(isCheckedOut()) {
			this.dailyCount = DefaultPeriodCalculator.countDays(this.checkin, this.checkout);
		}
	}

	public String getRenterName() {
		return renterName;
	}

	public String getCheckin() {
		return checkin;
	}

	public String getCheckout() {
		return checkout;
	}

	public int getDailyCount() {
		return dailyCount;
	}

	public double getTotalRate() {
		return dailyCount * STANDARD_DAILY_RATE * room.luxuryRate();
	}
	
	public boolean isCheckedOut() {
		return checkout != null;
	}

	public void setCheckout(String checkout) throws ParseException {
		this.checkout = checkout;
		this.dailyCount = DefaultPeriodCalculator.countDays(this.checkin, this.checkout);
	}

	public void setRoom(Room room) {
		this.room = room;		
	}

	public int getGuests() {
		return guests;
	}
}
package ead2.poo.atps.marau.rooms;

import ead2.poo.atps.marau.Booking;

public class StandardRoom extends Room {

	public final static Room EMPTY = new StandardRoom(null);
	
	public StandardRoom(Booking booking) {
		super(booking);
	}

	@Override
	public RoomType getRoomType() {
		return RoomType.STANDARD;
	}

	@Override
	public double luxuryRate() {
		return 1.0;
	}
	
	@Override
	public Room getEmpty() {
		return EMPTY;
	}
}
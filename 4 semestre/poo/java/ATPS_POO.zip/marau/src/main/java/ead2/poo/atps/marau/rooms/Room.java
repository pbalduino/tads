package ead2.poo.atps.marau.rooms;

import java.text.ParseException;

import ead2.poo.atps.marau.Booking;

public abstract class Room {

	private Booking booking;

	protected Room(Booking booking) {
		this.booking = booking;
		if(!isEmpty()) {
			booking.setRoom(this);
		}
	}

	public final boolean isEmpty() {
		return booking == null;
	}

	@Override
	public final String toString() {
		return getRoomType() + (isEmpty() ? " _Vazio_" : " Ocupado");
	}

	public final Booking checkout(String checkout) throws ParseException {
		booking.setCheckout(checkout);
		return booking;
	}

	public abstract RoomType getRoomType();

	public abstract double luxuryRate();

	public abstract Room getEmpty();
}
package ead2.poo.atps.marau.rooms;

import ead2.poo.atps.marau.Booking;

public class CottageRoom extends Room {
	
	public final static Room EMPTY = new CottageRoom(null);
	private Booking booking;

	public CottageRoom(Booking booking) {
		super(booking);
		this.booking = booking;
	}
	
	@Override
	public RoomType getRoomType() {
		return RoomType.COTTAGE;
	}
	
	@Override
	public double luxuryRate() {
		return 1.2 + (0.1 * (double)booking.getGuests());
	}

	@Override
	public Room getEmpty() {
		return EMPTY;
	}
}

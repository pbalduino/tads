/**
 * 
 * Classe responsável pelo cálculo de dias de hospedagem
 * 
 */
package ead2.poo.atps.marau;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.TimeZone;

public class DefaultPeriodCalculator {
	
	private static final DateFormat DATE_FORMATTER;
	private static final ZoneId UTC_ZONE = ZoneId.of("UTC");
	
	static {
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		DATE_FORMATTER = new SimpleDateFormat("dd/MM/yyyy hh:mm");
	}
	

	/**
	* countDays 
	* Retorna a quantidade de diárias entre a entrada e a saída do hóspede
	* 
	* Para isso a função recebe as datas em formato texto, como 
	* dd/mm/aaaa hh:mm", e as converte para o tipo Date. Em seguida são
	* subtraídas doze horas da data de entrada e são somadas doze horas na data
	* de saída. Então as horas são descartadas e é calculada a diferença de
	* dias entre saída e entrada.
	*/
	public static int countDays(final String checkin, final String checkout) throws ParseException {
		// calcular inicio da primeira diaria de fato
		LocalDate checkinDay = dailyStart(DATE_FORMATTER.parse(checkin));
			
		// calcular fim da ultima diaria de fato
		LocalDate checkoutDay = dailyEnd(DATE_FORMATTER.parse(checkout));
		
		// calcular diferença entre as duas datas			
		Period period = Period.between(LocalDate.from(checkinDay), LocalDate.from(checkoutDay));
		
		return period.getDays();
	}

	private static LocalDate dailyStart(Date checkin) {
		return checkin.toInstant()
				       .minus(Duration.ofHours(12))
				       .truncatedTo(ChronoUnit.DAYS)
				       .atZone(UTC_ZONE)
					   .toLocalDate();
	}

	private static LocalDate dailyEnd(Date checkout) {
		return checkout.toInstant()
					   .plus(Duration.ofHours(12))
					   .truncatedTo(ChronoUnit.DAYS)
					   .atZone(UTC_ZONE)
					   .toLocalDate();
	}
}
package ead2.poo.atps.marau.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public final class KeyboardReader {
	
	private KeyboardReader() {
		
	}
	
	public static String readLineAsString(final String text) throws IOException {
		System.out.print(text);
		BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
		return keyboard.readLine();		
	}

	public static int readLineAsInteger(final String text) throws IOException {
		int result = 0;
		
		while(true) {
			String line = readLineAsString(text);
			
			try {
				result = Integer.parseInt(line);
				break;
			} catch (NumberFormatException e) {
				System.out.println("Informe um número inteiro");
			}
		}
		
		return result;
	}

	public static double readLineAsDouble(String text) throws IOException {
		double result = 0;
		
		while(true) {
			String line = readLineAsString(text);
			try {
				result = Double.parseDouble(line.replace(',', '.'));
				break;
			} catch (NumberFormatException e) {
				System.out.println("Formato incorreto. Você pode usar ponto ou vírgula para separar os centavos");
			}
		}
		
		return result;
	}

	public static String readLineAsString(String text, String format) throws IOException {
		String line;
		while(true) {
			line = readLineAsString(text);
			
			try {
				new SimpleDateFormat(format).parse(line);
				break;
			} catch (ParseException e) {
				System.out.println("Data inválida. Use o formato " + format);
			}
		}
		
		return line;
	}

	public static int readKey() throws IOException {
		BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
		return keyboard.read();
	}	
}
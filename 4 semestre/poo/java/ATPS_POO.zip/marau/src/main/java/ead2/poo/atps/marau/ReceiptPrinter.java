package ead2.poo.atps.marau;

import java.io.PrintStream;

public class ReceiptPrinter {
	
	private static PrintStream out = System.out;
	
	public static void setPrintStream(final PrintStream out) {
		ReceiptPrinter.out = out;
	}
	
	public static void print(Booking booking, int roomNumber) {
		out.println("========================================");
		out.printf("Locatário: %s%n", booking.getRenterName());
		out.printf("Quarto número: %d%n" , roomNumber);
		out.printf("Data e horário de entrada: %s%n", booking.getCheckin());
		out.printf("Data e horário de saída: %s%n", booking.getCheckout());
		out.printf("Número de diárias: %d%n", booking.getDailyCount());
		out.printf("Total devido: %.2f%n", booking.getTotalRate());
		out.println("========================================");
	}
}
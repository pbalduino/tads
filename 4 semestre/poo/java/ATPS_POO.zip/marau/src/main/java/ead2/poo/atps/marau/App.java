/**
 * Classe que inicia a aplicação.
 * 
 */
package ead2.poo.atps.marau;

import java.io.IOException;
import java.text.ParseException;

import ead2.poo.atps.marau.rooms.RoomList;
import ead2.poo.atps.marau.util.KeyboardReader;

public final class App {

	private static final char EXIT = '0';
	private static final char CHECKIN = '1';
	private static final char CHECKOUT = '2';
	private static final char UPDATE_DAILY_RATE = '3';

	private final RoomList rooms;

	public App(RoomList rooms) {
		this.rooms = rooms;
	}

	public static void main(String[] args) throws Exception {
		RoomList rooms = new RoomList();
		
		rooms.setSize(25, 25, 10);

		App app = new App(rooms);
		
		app.systemParameters();
		
		app.menu();
	}

	private void menu() throws IOException, ParseException {
		int option = 99;
		
		do {
			option = printMenu();

			switch (option) {
			case EXIT:
				System.out.println();
				System.out.println("Até logo.");
				
				break;

			case CHECKIN:
				doCheckin();
				break;
			
			case CHECKOUT:
				doCheckout();				
				break;

			case UPDATE_DAILY_RATE:
				systemParameters();
				break;
				
			default:
				System.out.println("Opção inválida");
				
				KeyboardReader.readKey();
				
				break;
			}
		} while (option != EXIT);
	}

	private int printMenu() throws IOException {
		clearScreen();
		System.out.println("= Menu do sistema =");
		System.out.println(" 1 - Registrar entrada");
		System.out.println(" 2 - Registrar saída");
		System.out.println(" 3 - Atualizar valor de diária");
		System.out.println(" -----------------------------");
		System.out.println(" 0 - Sair");
		
		System.out.println();
		System.out.printf(" = Diária padrão: %.2f%n", Booking.STANDARD_DAILY_RATE);
		System.out.println();
		System.out.println(" = Ocupação =");
		System.out.println(rooms);

		
		return KeyboardReader.readKey();
	}

	private void clearScreen() {
		for(int i = 0; i < 1000; i++) {
			System.out.println();
		}
		
	}

	private void systemParameters() throws IOException {
		System.out.println("= Parâmetros do sistema =");
		Booking.STANDARD_DAILY_RATE = KeyboardReader.readLineAsDouble("Valor padrão da diária  : ");	
		System.out.println();
	}

	/**
	 * Método que abre uma nova hospedagem
	 */
	private void doCheckin() throws IOException, ParseException {
		rooms.addBooking(getBoookingData());
	}
	
	private void doCheckout() throws IOException, ParseException {
		System.out.println();
		System.out.println("= Saída do quarto =");
		int roomNumber = KeyboardReader.readLineAsInteger("Informe o número do quarto (1 - " + rooms.count() + "): ");
		
		if(!rooms.isEmpty(roomNumber)) {
			String checkout = KeyboardReader.readLineAsString("Data de saída : ", "dd/MM/yyyy hh:mm");
			Booking booking = rooms.checkout(roomNumber, checkout);
			ReceiptPrinter.print(booking, roomNumber);
		} else {
			System.out.println("Quarto está vazio");
		}
		KeyboardReader.readKey();
	}
	
	private Booking getBoookingData() throws IOException, ParseException {	
		System.out.println("= Reserva de quarto =");
			
		String renterName = KeyboardReader.readLineAsString("Nome do locatario: ");
		String checkin = KeyboardReader.readLineAsString("Data de entrada  : ", "dd/MM/yyyy hh:mm");
		
		int guests = KeyboardReader.readLineAsInteger("Camas extra      : ");
		System.out.println();

		return new Booking(renterName, checkin, guests);
	}
}
package ead2.poo.atps.marau.rooms;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import ead2.poo.atps.marau.Booking;
import ead2.poo.atps.marau.util.KeyboardReader;

public class RoomList {
	private final List<Room> rooms;
	
	public RoomList() {
		rooms = new ArrayList<Room>();
	}

	public void setSize(final int standardRooms) {
		for(int room = 0; room < standardRooms; room++) {
			rooms.add(StandardRoom.EMPTY);
		}
	}

	public void setSize(int standardRooms, int cottages) {
		setSize(standardRooms);
		
		for(int room = 0; room < cottages; room++) {
			rooms.add(CottageRoom.EMPTY);
		}
	}

	public void setSize(int standardRooms, int fancyRooms, int cottages) {
		for(int room = 0; room < fancyRooms; room++) {
			rooms.add(FancyRoom.EMPTY);
		}

		setSize(standardRooms, cottages);
	}

	public int addBooking(Booking booking) throws IOException {
		int roomNumber;
		
		do {
			roomNumber = KeyboardReader.readLineAsInteger("Número do quarto : ");
			if(!isEmpty(roomNumber)) {
				System.out.println("O quarto está ocupado");
			}
		}while(!isEmpty(roomNumber));

		Room room = null;
		
		switch (rooms.get(roomNumber - 1).getRoomType()) {
		case STANDARD:
			room = new StandardRoom(booking);
			break;

		case COTTAGE:
			room = new CottageRoom(booking);
			break;
		
		case BATH:
			room = new FancyRoom(booking);
			break;
		}
		
		rooms.set(roomNumber - 1, room);
		
		return roomNumber;
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		
		for(int room = 0; room < count(); room++) {
			buffer.append("[")
			      .append(room < 9 ? "0" : "")
			      .append(room + 1)
			      .append(": ")
			      .append(rooms.get(room))
			      .append("] ")
			      .append(room > 0 && (room + 1) % 5 == 0 ? "\n" : "");
		}
		
		return buffer.toString();
	}

	public int count() {
		return rooms.size();
	}

	public boolean isEmpty(final int roomNumber) {
		return (roomNumber - 1 > 0 && roomNumber - 1 < count() ? rooms.get(roomNumber - 1).isEmpty() : true);
	}

	public Booking checkout(int roomNumber, String checkout) throws ParseException {
		Booking booking = rooms.get(roomNumber - 1).checkout(checkout);
		
		rooms.set(roomNumber - 1, rooms.get(roomNumber - 1).getEmpty());
		
		return booking;
	}
}

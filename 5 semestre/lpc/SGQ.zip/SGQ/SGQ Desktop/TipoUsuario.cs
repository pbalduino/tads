﻿namespace SGQ.Model
{
    public enum TipoUsuario
    {
        Invalido = 0,
        Usuario,
        Admin        
    }
}

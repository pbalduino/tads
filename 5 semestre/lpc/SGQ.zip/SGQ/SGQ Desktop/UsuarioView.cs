﻿using System.Windows.Forms;

namespace SGQ.View
{
    public partial class UsuarioView : Form
    {
        public UsuarioView()
        {
            InitializeComponent();
        }
    }
}
